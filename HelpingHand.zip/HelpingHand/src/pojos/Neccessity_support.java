package pojos;

public class Neccessity_support{
	private int Ne_id;
	private String name;
	private int quantity;
	private int C_id;
	//default constructor
	public Neccessity_support() {
		super();
	}
	//constructor
	public Neccessity_support(int ne_id, String name, int quantity, int c_id) {
		super();
		Ne_id = ne_id;
		this.name = name;
		this.quantity = quantity;
		C_id = c_id;
	}
	//getter and setter
	public int getNe_id() {
		return Ne_id;
	}
	public void setNe_id(int ne_id) {
		Ne_id = ne_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getC_id() {
		return C_id;
	}
	public void setC_id(int c_id) {
		C_id = c_id;
	}
	//tostring
	@Override
	public String toString() {
		return "Neccessity_support [Ne_id=" + Ne_id + ", name=" + name + ", quantity=" + quantity + ", C_id=" + C_id
				+ "]";
	}
	
	
}
