package pojos;



public class EducationSupport {
	//properties
	private int E_id;
	private double amount;
	private String name;
	private String gender;
	private int C_id;
	private int U_id;
	private int N_id;
	//Constructor
	public EducationSupport() {
		System.out.println("In default constructor Education support");
	}
	public EducationSupport(int e_id, double amount, String name, String gender, int c_id, int u_id, int n_id) {
		super();
		E_id = e_id;
		this.amount = amount;
		this.name = name;
		this.gender = gender;
		C_id = c_id;
		U_id = u_id;
		N_id = n_id;
	}
	//getter setter
	public int getE_id() {
		return E_id;
	}
	public void setE_id(int e_id) {
		E_id = e_id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getC_id() {
		return C_id;
	}
	public void setC_id(int c_id) {
		C_id = c_id;
	}
	public int getU_id() {
		return U_id;
	}
	public void setU_id(int u_id) {
		U_id = u_id;
	}
	public int getN_id() {
		return N_id;
	}
	public void setN_id(int n_id) {
		N_id = n_id;
	}
	//tostring
	@Override
	public String toString() {
		return "EducationSupport [E_id=" + E_id + ", amount=" + amount + ", name=" + name + ", gender=" + gender
				+ ", C_id=" + C_id + ", U_id=" + U_id + ", N_id=" + N_id + "]";
	}
	
	
}
