package pojos;

import java.time.LocalDate;

public class Hapiness_Support {
	//Properties
	private int H_id;
	private LocalDate time;
	private String location;
	private int U_id;
	private int N_id;
	//Default Constructor
	public Hapiness_Support() {
		super();
	}
	// Constructor
	public Hapiness_Support(int h_id, LocalDate time, String location, int u_id, int n_id) {
		super();
		H_id = h_id;
		this.time = time;
		this.location = location;
		U_id = u_id;
		N_id = n_id;
	}
	public int getH_id() {
		return H_id;
	}
	public void setH_id(int h_id) {
		H_id = h_id;
	}
	public LocalDate getTime() {
		return time;
	}
	public void setTime(LocalDate time) {
		this.time = time;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getU_id() {
		return U_id;
	}
	public void setU_id(int u_id) {
		U_id = u_id;
	}
	public int getN_id() {
		return N_id;
	}
	public void setN_id(int n_id) {
		N_id = n_id;
	}
	//tostring
	@Override
	public String toString() {
		return "Hapiness_Support [H_id=" + H_id + ", time=" + time + ", location=" + location + ", U_id=" + U_id
				+ ", N_id=" + N_id + "]";
	}
	
	

}
